globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/q3mOkSnKMT8Q8LIN8VMNc/_buildManifest.js",
    "static/q3mOkSnKMT8Q8LIN8VMNc/_ssgManifest.js",
    "static/q3mOkSnKMT8Q8LIN8VMNc/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/05r8vu30r1_j~.js",
    "static/chunks/146rw096sf~36.js",
    "static/chunks/0je0xdg~7dmqj.js",
    "static/chunks/0vxi98ewbbk5w.js",
    "static/chunks/turbopack-12p59w3iwrtcq.js"
  ]
};
